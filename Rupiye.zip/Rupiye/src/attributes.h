

#ifndef RUPIYE_ATTRIBUTES_H
#define RUPIYE_ATTRIBUTES_H

#if defined(__clang__)
#  if __has_attribute(lifetimebound)
#    define LIFETIMEBOUND [[clang::lifetimebound]]
#  else
#    define LIFETIMEBOUND
#  endif
#else
#  define LIFETIMEBOUND
#endif

#endif // RUPIYE_ATTRIBUTES_H
