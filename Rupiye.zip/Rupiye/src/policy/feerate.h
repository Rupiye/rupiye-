// Copyright (c) 2021 locky
// Copyright (c) 2021 The Rupiye Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef RUPIYE_POLICY_FEERATE_H
#define RUPIYE_POLICY_FEERATE_H

#include <amount.h>
#include <serialize.h>

#include <string>

const std::string CURRENCY_UNIT = "INR"; // One formatted unit
const std::string CURRENCY_ATOM = "paise"; // One indivisible minimum value unit

/* Used to determine type of fee estimation requested */
enum class FeeEstimateMode {
    UNSET,        //!< Use default settings based on other criteria
    ECONOMICAL,   //!< Force estimateSmartFee to use non-conservative estimates
    CONSERVATIVE, //!< Force estimateSmartFee to use conservative estimates
    INR_KVB,      //!< Use INR/kvB fee rate unit
    PAISE_VB,       //!< Use paise/vB fee rate unit
};

/**
 * Fee rate in paise per kilobyte: CAmount / kB
 */
class CFeeRate
{
private:
    CAmount nPaisePerK; // unit is paise-per-1,000-bytes

public:
    /** Fee rate of 0 paise per kB */
    CFeeRate() : nPaisePerK(0) { }
    template<typename I>
    explicit CFeeRate(const I _nPaisePerK): nPaisePerK(_nPaisePerK) {
        // We've previously had bugs creep in from silent double->int conversion...
        static_assert(std::is_integral<I>::value, "CFeeRate should be used without floats");
    }
    /** Constructor for a fee rate in paise per kvB (paise/kvB).
     *
     *  Passing a num_bytes value of COIN (1e8) returns a fee rate in paise per vB (paise/vB),
     *  e.g. (nFeePaid * 1e8 / 1e3) == (nFeePaid / 1e5),
     *  where 1e5 is the ratio to convert from INR/kvB to paise/vB.
     */
    CFeeRate(const CAmount& nFeePaid, uint32_t num_bytes);
    /**
     * Return the fee in paise for the given size in bytes.
     */
    CAmount GetFee(uint32_t num_bytes) const;
    /**
     * Return the fee in paise for a size of 1000 bytes
     */
    CAmount GetFeePerK() const { return GetFee(1000); }
    friend bool operator<(const CFeeRate& a, const CFeeRate& b) { return a.nPaisePerK < b.nPaisePerK; }
    friend bool operator>(const CFeeRate& a, const CFeeRate& b) { return a.nPaisePerK > b.nPaisePerK; }
    friend bool operator==(const CFeeRate& a, const CFeeRate& b) { return a.nPaisePerK == b.nPaisePerK; }
    friend bool operator<=(const CFeeRate& a, const CFeeRate& b) { return a.nPaisePerK <= b.nPaisePerK; }
    friend bool operator>=(const CFeeRate& a, const CFeeRate& b) { return a.nPaisePerK >= b.nPaisePerK; }
    friend bool operator!=(const CFeeRate& a, const CFeeRate& b) { return a.nPaisePerK != b.nPaisePerK; }
    CFeeRate& operator+=(const CFeeRate& a) { nPaisePerK += a.nPaisePerK; return *this; }
    std::string ToString(const FeeEstimateMode& fee_estimate_mode = FeeEstimateMode::INR_KVB) const;

    SERIALIZE_METHODS(CFeeRate, obj) { READWRITE(obj.nPaisePerK); }
};

#endif //  RUPIYE_POLICY_FEERATE_H
