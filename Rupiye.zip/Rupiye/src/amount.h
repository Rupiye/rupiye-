#ifndef RUPIYE_AMOUNT_H
#define RUPIYE_AMOUNT_H

#include <stdint.h>

/** Amount in paise (Can be negative) */
typedef int64_t CAmount;

static const CAmount COIN = 1000000000;

/** No amount larger than this (in paise) is valid.
 *
 * Note that this constant is *not* the total money supply, which in Rupiye
 * currently happens to be less than 21,000,0000000 INR for various reasons, but
 * rather a sanity check. As this sanity check is used by consensus-critical
 * validation code, the exact value of the MAX_MONEY constant is consensus
 * critical; in unusual circumstances like a(nother) overflow bug that allowed
 * for the creation of coins out of thin air modification could lead to a fork.
 * */
static const CAmount MAX_MONEY = 210000000000 * COIN;
inline bool MoneyRange(const CAmount& nValue) { return (nValue >= 0 && nValue <= MAX_MONEY); }

#endif //  RUPIYE_AMOUNT_H
