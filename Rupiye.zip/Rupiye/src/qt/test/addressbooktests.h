

#ifndef RUPIYE_QT_TEST_ADDRESSBOOKTESTS_H
#define RUPIYE_QT_TEST_ADDRESSBOOKTESTS_H

#include <QObject>
#include <QTest>

namespace interfaces {
class Node;
} // namespace interfaces

class AddressBookTests : public QObject
{
public:
    explicit AddressBookTests(interfaces::Node& node) : m_node(node) {}
    interfaces::Node& m_node;

    Q_OBJECT

private Q_SLOTS:
    void addressBookTests();
};

#endif // RUPIYE_QT_TEST_ADDRESSBOOKTESTS_H
