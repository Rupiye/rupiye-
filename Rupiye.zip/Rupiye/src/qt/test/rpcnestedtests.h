
#ifndef RUPIYE_QT_TEST_RPCNESTEDTESTS_H
#define RUPIYE_QT_TEST_RPCNESTEDTESTS_H

#include <QObject>
#include <QTest>

namespace interfaces {
class Node;
} // namespace interfaces

class RPCNestedTests : public QObject
{
public:
    explicit RPCNestedTests(interfaces::Node& node) : m_node(node) {}
    interfaces::Node& m_node;

    Q_OBJECT

    private Q_SLOTS:
    void rpcNestedTests();
};

#endif // RUPIYE_QT_TEST_RPCNESTEDTESTS_H
