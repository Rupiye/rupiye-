
#ifndef RUPIYE_QT_TEST_URITESTS_H
#define RUPIYE_QT_TEST_URITESTS_H

#include <QObject>
#include <QTest>

class URITests : public QObject
{
    Q_OBJECT

private Q_SLOTS:
    void uriTests();
};

#endif // RUPIYE_QT_TEST_URITESTS_H
