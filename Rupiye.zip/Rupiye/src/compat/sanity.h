
#ifndef RUPIYE_COMPAT_SANITY_H
#define RUPIYE_COMPAT_SANITY_H

bool glibcxx_sanity_test();

#endif // RUPIYE_COMPAT_SANITY_H
